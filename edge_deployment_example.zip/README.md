# Edge Deployment Example: PyTorch to SNPE

## Overview
This project demonstrates an end-to-end pipeline for deploying a PyTorch model to a Qualcomm Snapdragon device using SNPE.

## Pipeline
1. Train or load a PyTorch model.
2. Convert to ONNX.
3. Convert ONNX to DLC using SNPE.
4. Run inference on-device using SNPE tools.

## Target
- Hardware: Snapdragon 865 (Hexagon DSP)
- Model: MobileNetV2
- Input: 224x224 RGB image
- Format: ONNX → DLC

## Results
- Accuracy: 71.9% top-1 (ImageNet subset)
- Latency: 35 ms per frame on DSP
- Power: ~1.2W average

## Instructions
1. Run `conversion/export_to_onnx.py` to export the model.
2. Run `conversion/onnx_to_dlc.sh` to convert ONNX to DLC.
3. Run `inference/snpe_infer.sh` on your device.
